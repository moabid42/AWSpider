def lambda_handler(event):
    print(event)
